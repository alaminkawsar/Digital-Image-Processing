import numpy as np
import cv2
import matplotlib.pyplot as plt


img_path = '/home/kawsar/Desktop/Class_Resource/4th Year 1st semester/ImageProcessingLab/Assignment/1810576130_Assignment7/flower.jpeg'
#print(img_path)

x, y, pos = 4, 2, 1

plt_list = []
rgb = plt.imread(img_path)
grayscale = cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
temp = (grayscale-50)%200

left = temp
right = temp + 50
middle = (temp %150)+50

plt_list.append([grayscale, 'Main Image '])
plt_list.append([left,'Left '])
plt_list.append([right, 'Right '])
plt_list.append([middle,'Middle '])

for item in plt_list:
    plt.subplot(x,y,pos)
    plt.title(item[1])
    plt.imshow(item[0],cmap='gray')

    plt.subplot(x,y,pos+1)
    plt.title(item[1]+'Histogram')
    histr = cv2.calcHist([item[0]],[0],None,[256],[0,256])
    plt.plot(histr,color = 'blue')
    plt.xlim([0,256])
    
    pos += 2
    
    plt.subplots_adjust(left=0.1,
                    bottom=0.1, 
                    right=0.9, 
                    top=0.9, 
                    wspace=0.5, 
                    hspace=0.4)


plt.show()
#plt.savefig("/home/kawsar/Desktop/Class_Resource/4th Year 1st semester/ImageProcessingLab/Assignment/1810576130_Assignment7/Output.png")



'''
plt_list.append(grayscale)
for pos in range(len(plt_list)):
    plt.subplot(x,y,pos)
    plt.imshow(grayscale,cmap='gray')
plt.show()

'''


