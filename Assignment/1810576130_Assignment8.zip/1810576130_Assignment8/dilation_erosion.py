import numpy as np
import cv2 
import matplotlib.pyplot as plt

img_path = '1810576130_Assignment8/tree.jpg'
img = plt.imread(img_path)
_, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
# Taking a matrix of size 5 as the kernel
kernel1 = np.ones((5, 5), np.uint8)

x, y, pos = 2, 3, 1

#erosion Image
img_erosion = cv2.erode(img, kernel1, iterations=1)

#dilation Image
img_dilation = cv2.dilate(img, kernel1, iterations=1)

#closing_image
closing_img = cv2.dilate(img_erosion, kernel1, iterations=1)

#opening image
opening_img = cv2.erode(img_dilation, kernel1, iterations=1)

image_list = []
title_list = ['Main Image','Erosion Image','Dilation Image','Closing Image','Openning Imgage']

image_list.append(img)
image_list.append(img_dilation)
image_list.append(img_erosion)
image_list.append(closing_img)
image_list.append(opening_img)

# plt.figure(figsize=(20,20))
# plt.subplot(x, y, pos)
# plt.imshow(img)

for item in image_list:
    plt.subplot(x, y, pos)
    plt.title(title_list[pos-1])
    plt.imshow(item)
    pos += 1

plt.show()
